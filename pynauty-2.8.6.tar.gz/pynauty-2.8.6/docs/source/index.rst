.. Pynauty documentation master file, created by
   sphinx-quickstart on Tue Feb 16 22:47:42 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Pynauty's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro
   install
   guide


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
