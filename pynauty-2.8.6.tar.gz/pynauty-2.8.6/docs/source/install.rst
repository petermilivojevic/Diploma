Installation
============

Pleas see the Readme_ at Github.
  
.. _Readme: https://github.com/pdobsan/pynauty/blob/main/README.md
.. _Nauty: https://cs.anu.edu.au/people/Brendan.McKay/nauty/
.. _Traces: https://pallini.di.uniroma1.it/
